#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#define bit1 1U << 1
#define bit3 1U << 3
#define DEBOUNCE_DELAY 50000


void delay(uint32_t count) {
    while(count--);
}

void debounce(uint32_t pin) {
    delay(DEBOUNCE_DELAY);
    while(GPIOPinRead(GPIO_PORTF_BASE, pin) == 0);
    delay(DEBOUNCE_DELAY);
}


int main (void)
{

SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_OSC | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

SysCtlPeripheralEnable (SYSCTL_PERIPH_GPIOF);
GPIOPinTypeGPIOOutput (GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3);
GPIOPinTypeGPIOInput (GPIO_PORTF_BASE, GPIO_PIN_4);  //boton como entrada
GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU); //configuracion como pull-up

while (1) {

    if (GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0) {

        //Se presiona el boton
        debounce(GPIO_PIN_4);

        // Inicia semaforo
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0xff); //verde
        SysCtlDelay(2500000);

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0x00); //verde parpadeante
        SysCtlDelay(1000000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0xff);
        SysCtlDelay(1000000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0x00);
        SysCtlDelay(1000000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0xff);
        SysCtlDelay(1000000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0x00);
        SysCtlDelay(1000000);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0xff);
        SysCtlDelay(2500000);

         GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0xff); //amarillo
         SysCtlDelay(2500000);

         GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0x00); //rojo
         SysCtlDelay(2500000);


    } else {

        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0);
        GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0);
    }

}
}
